#!/bin/bash

# Exit on error
set -e

# Create and activate virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Create data directory if it doesn't exist
mkdir -p data

# Initialize the database
echo "Initializing database..."
PYTHONPATH=. python scripts/init_db.py

# Start FastAPI backend
echo "Starting FastAPI backend..."
python -m uvicorn ragchat.main:app --host 0.0.0.0 --port 8000 --reload &
FASTAPI_PID=$!

# Wait a moment for FastAPI to start
sleep 2

# Start Streamlit frontend
echo "Starting Streamlit frontend..."
streamlit run ragchat/frontend/app.py --server.port 8501 &
STREAMLIT_PID=$!

# Function to handle cleanup
cleanup() {
    echo "Shutting down servers..."
    kill $FASTAPI_PID
    kill $STREAMLIT_PID
    deactivate
    exit 0
}

# Set up trap for cleanup
trap cleanup SIGINT SIGTERM

# Wait for both processes
wait