# RAG Chat Application

A multi-model RAG (Retrieval-Augmented Generation) chat application with real-time capabilities.

## Features

- Multiple chat sessions with different language models
- Support for various LLM providers:
  - OpenAI GPT-3.5
  - Google Gemini
  - Anthropic Claude
  - BLOOM
  - LLaMA
  - MPT
- Document processing (PDF, DOCX, TXT)
- RSS feed integration
- Real-time chat with WebSocket support
- Multi-user support
- Chat sharing capabilities
- Clean and intuitive UI

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd ragchat
```

2. Set up environment variables in `.env`:
```
OPENAI_API_KEY=your_openai_key
GOOGLE_API_KEY=your_google_key
ANTHROPIC_API_KEY=your_anthropic_key
HF_TOKEN=your_huggingface_token
```

3. Run the application:
```bash
chmod +x run.sh  # Make the script executable
./run.sh
```

The script will:
- Create a virtual environment
- Install dependencies
- Initialize the database
- Start the FastAPI backend (http://localhost:8000)
- Start the Streamlit frontend (http://localhost:8501)

## Usage

1. Open http://localhost:8501 in your browser
2. Create a new chat by entering a name and selecting a model
3. Upload documents or add RSS feeds for context
4. Start chatting with the selected model
5. Share chats with others using the share button

## API Documentation

The API documentation is available at http://localhost:8000/docs

## Project Structure

```
ragchat/
├── api/                 # FastAPI routes and schemas
├── database/           # Database models and manager
├── frontend/          # Streamlit frontend components
├── models/            # LLM model implementations
└── utils/             # Utility functions and helpers
```

## Development

To run tests:
```bash
pytest
```

To format code:
```bash
black .
```