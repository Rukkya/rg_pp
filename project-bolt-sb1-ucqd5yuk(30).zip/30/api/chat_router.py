from fastapi import APIRouter, HTTPException, WebSocket, Depends
from typing import List, Optional
from pydantic import BaseModel
from database.db_manager import DatabaseManager
from models.model_factory import ModelFactory
from utils.document_processor import DocumentProcessor
from utils.data_manager import DataManager
from datetime import datetime
import asyncio
from fastapi.security import APIKeyHeader
from starlette.websockets import WebSocketDisconnect

router = APIRouter()
db_manager = DatabaseManager()
doc_processor = DocumentProcessor()
data_manager = DataManager(db_manager)

# WebSocket connections store
class ConnectionManager:
    def __init__(self):
        self.active_connections: dict = {}  # chat_id -> List[WebSocket]

    async def connect(self, websocket: WebSocket, chat_id: int):
        await websocket.accept()
        if chat_id not in self.active_connections:
            self.active_connections[chat_id] = []
        self.active_connections[chat_id].append(websocket)

    async def disconnect(self, websocket: WebSocket, chat_id: int):
        if chat_id in self.active_connections:
            self.active_connections[chat_id].remove(websocket)

    async def broadcast_message(self, chat_id: int, message: dict):
        if chat_id in self.active_connections:
            for connection in self.active_connections[chat_id]:
                await connection.send_json(message)

manager = ConnectionManager()

class ChatMessage(BaseModel):
    content: str
    role: str = "user"

class ChatResponse(BaseModel):
    id: int
    content: str
    role: str
    timestamp: datetime

@router.websocket("/ws/chat/{chat_id}")
async def websocket_endpoint(websocket: WebSocket, chat_id: int):
    try:
        await manager.connect(websocket, chat_id)
        
        while True:
            data = await websocket.receive_json()
            
            # Process the message
            chat = db_manager.get_chat_by_id(chat_id)
            if not chat:
                await websocket.close()
                return
            
            # Save user message
            user_message = data.get("content", "")
            db_manager.add_message(chat_id, "user", user_message)
            
            # Get context and generate response
            doc_context = doc_processor.search_similar(str(chat_id), user_message, chat.model)
            feed_context = data_manager.get_relevant_context(user_message, str(chat_id), chat.model)
            context = "\n".join(doc_context + [feed_context]) if feed_context else "\n".join(doc_context)
            
            # Get model response
            model = ModelFactory.create_model(chat.model)
            prompt = f"Context: {context}\n\nQuestion: {user_message}"
            response = model.predict(prompt)
            
            # Save assistant message
            db_manager.add_message(chat_id, "assistant", response)
            
            # Broadcast to all connected clients
            await manager.broadcast_message(chat_id, {
                "role": "assistant",
                "content": response,
                "timestamp": datetime.utcnow().isoformat()
            })
            
    except WebSocketDisconnect:
        await manager.disconnect(websocket, chat_id)

@router.post("/chat/{chat_id}/messages")
async def send_message(chat_id: int, message: ChatMessage):
    chat = db_manager.get_chat_by_id(chat_id)
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    # Save user message
    db_manager.add_message(chat_id, message.role, message.content)
    
    if message.role == "user":
        # Get context and generate response
        doc_context = doc_processor.search_similar(str(chat_id), message.content, chat.model)
        feed_context = data_manager.get_relevant_context(message.content, str(chat_id), chat.model)
        context = "\n".join(doc_context + [feed_context]) if feed_context else "\n".join(doc_context)
        
        # Get model response
        model = ModelFactory.create_model(chat.model)
        prompt = f"Context: {context}\n\nQuestion: {message.content}"
        response = model.predict(prompt)
        
        # Save assistant message
        db_manager.add_message(chat_id, "assistant", response)
        
        return ChatResponse(
            id=chat_id,
            content=response,
            role="assistant",
            timestamp=datetime.utcnow()
        )
    
    return ChatResponse(
        id=chat_id,
        content=message.content,
        role=message.role,
        timestamp=datetime.utcnow()
    )